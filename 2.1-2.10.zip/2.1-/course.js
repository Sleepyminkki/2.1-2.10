import React from 'react';

const Course = ({course}) => {
  return (
    <div>

      {course.map((names, index) => {
        const total = names.parts.reduce((sum, part) => {
          return sum + part.exercises;
        }, 0);

        return (
          <div key={index}>
            <h1>{names.name}</h1>
            {names.parts.map((work, innerIndex) => {

              return (
                <div key={innerIndex}>
                  <p>{work.name} {work.exercises}</p>
                </div>
              );
            })}
            <b>total of {total} exercises</b>
          </div>
        );
      })}
    </div>
  );
};

export default Course;